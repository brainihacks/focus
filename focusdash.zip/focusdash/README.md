# Insurance Dashboard

Care insurance data analysis dashboard based on government reported UK road data from 2000-2020. Made with Python, Plotly, Dash and Bootrstrap. Created for the TU/e Data Visualization course of 2022